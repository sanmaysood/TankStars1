package com.tankstars.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

//by Sanmay(2021095) & Aniket(2021231)

public class TanksStars extends Game {
	public PreloginScreen preloginScreen;
	public OptionsScreen optionsScreen;
	public GameScreen gameScreen;
	public ChooseTanksScreen chooseTanksScreen;
	public SavedGamesScreen savedGamesScreen;

	
	@Override
	public void create () {
		preloginScreen=new PreloginScreen();
		optionsScreen=new OptionsScreen(this);
		gameScreen=new GameScreen();
		chooseTanksScreen=new ChooseTanksScreen(this);
		savedGamesScreen=new SavedGamesScreen(this);

		this.setScreen(gameScreen);
	}

	@Override
	public void render () {
		super.render();

	}
	
	@Override
	public void dispose () {

	}
}
