package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class SavedGamesScreen implements Screen {
    private final TanksStars tanksStars;
    private Stage stage;
    private Skin skin;
    private TextButton btnSlot1;
    private TextButton btnSlot2;
    private TextButton btnSlot3;
    private TextButton btnSlot4;
    private ImageButton btnOptions;


    public SavedGamesScreen(TanksStars tanksStars){
        this.tanksStars=tanksStars;
        this.stage=new Stage();


    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));


        Texture backgroundTex=new Texture(Gdx.files.internal("SavedGamesScreen.png"));
        TextureRegion backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        Image background=new Image(backgroundTexReg);

        stage.addActor(background);

        this.btnSlot1 = new TextButton("Game id-1", this.skin);
        this.btnSlot1.setPosition(300,350);
        this.btnSlot1.setSize(200,70);
        this.btnSlot2 = new TextButton("Game id-3", skin);
        this.btnSlot2.setPosition(300,250);
        this.btnSlot2.setSize(200,70);

        this.btnSlot3 = new TextButton("EMPTY", skin);
        this.btnSlot3.setPosition(300,150);
        this.btnSlot3.setSize(200,70);

        this.btnSlot4=new TextButton("Game id-5",this.skin);
        this.btnSlot4.setPosition(300,50);
        this.btnSlot4.setSize(200,70);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("BackButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("BackButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);



        stage.addActor(this.btnSlot1);
        stage.addActor(this.btnSlot2);
        stage.addActor(this.btnSlot3);
        stage.addActor(this.btnSlot4);
        stage.addActor(this.btnOptions);

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
