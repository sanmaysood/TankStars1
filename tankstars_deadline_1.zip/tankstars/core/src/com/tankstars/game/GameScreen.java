package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class GameScreen implements Screen {
    private Stage stage;
    private Skin skin;
    private light_tank_actor light_tank_actor;
    private infantry_tank_actor infantry_tank_actor;
    private cavalry_tank_actor cavalry_tank_actor;
    private Label gameLabel,player_1_Label,player_2_Label;
    private shootButton shootButton_P_1;
    private shootButton shootButton_P_2;
    private powerButton powerButton_P_1,powerButton_P_2;

    private ImageButton btnOptions;
    private ImageButton btnShoot;

    public GameScreen(){
        this.stage=new Stage();
    }


    @Override
    public void show() {

        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        Texture backgroundTex=new Texture(Gdx.files.internal("GameBackground.png"));
        TextureRegion backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        Image background=new Image(backgroundTexReg);

        gameLabel=new Label(" GameID:404",skin,"bold");
        gameLabel.setSize(250,50);
        gameLabel.setPosition(290,480);

        player_1_Label=new Label("P1",skin,"xp");
        player_1_Label.setSize(35,35);
        player_1_Label.setPosition(10,380);

        player_2_Label=new Label("P2",skin,"xp");
        player_2_Label.setSize(35,35);
        player_2_Label.setPosition(750,380);


        this.light_tank_actor=new light_tank_actor();
        this.cavalry_tank_actor=new cavalry_tank_actor();
        this.infantry_tank_actor=new infantry_tank_actor();
        this.light_tank_actor.sprite.setPosition(800-10-light_tank_actor.sprite.getWidth(),120);
        this.infantry_tank_actor.flipper();
        this.infantry_tank_actor.sprite.setPosition(10,150);
        //this.cavalry_tank_actor.sprite.setPosition(400,150);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.shootButton_P_1=new shootButton();
        this.shootButton_P_2=new shootButton();
        this.shootButton_P_1.sprite.setPosition(10,70);
        this.shootButton_P_2.sprite.setPosition(750,70);

        this.powerButton_P_1=new powerButton();
        this.powerButton_P_2=new powerButton();
        this.powerButton_P_1.sprite.setPosition(10,10);
        this.powerButton_P_2.sprite.setPosition(750,10);



        stage.addActor(background);
        stage.addActor(gameLabel);
        stage.addActor(player_1_Label);
        stage.addActor(player_2_Label);
        stage.addActor(this.btnOptions);
        stage.addActor(light_tank_actor);
        stage.addActor(infantry_tank_actor);
        stage.addActor(shootButton_P_1);
        stage.addActor(shootButton_P_2);
        stage.addActor(powerButton_P_1);
        stage.addActor(powerButton_P_2);

       // stage.addActor(cavalry_tank_actor);




        Gdx.input.setInputProcessor(stage);



    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act();
        stage.draw();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}

